from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QSizePolicy,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)


class RegistryTable(QWidget):
    def __init__(self, compact: bool = False, parent=None) -> None:
        super().__init__(parent)
        self.compact = compact

        desired_header = QLabel("Требуемая квартира")
        desired_header.setObjectName("desiredTableHeader")
        desired_header.setAlignment(Qt.AlignmentFlag.AlignCenter)
        offered_header = QLabel("Имеющаяся квартира")
        offered_header.setObjectName("offeredTableHeader")
        offered_header.setAlignment(Qt.AlignmentFlag.AlignCenter)

        group_layout = QHBoxLayout()
        group_layout.setContentsMargins(48, 0, 140, 0)
        group_layout.setSpacing(0)
        group_layout.addWidget(desired_header, 4)
        group_layout.addWidget(offered_header, 4)

        self.table = QTableWidget(0, 10)
        self.table.setObjectName("registryTable")
        self.table.setHorizontalHeaderLabels([
            "№", "Комнаты", "Площадь", "Этаж", "Район",
            "Комнаты", "Площадь", "Этаж", "Район", "Дата подачи",
        ])
        self.table.setSelectionBehavior(
            QAbstractItemView.SelectionBehavior.SelectRows
        )
        self.table.setSelectionMode(
            QAbstractItemView.SelectionMode.SingleSelection
        )
        self.table.setEditTriggers(
            QAbstractItemView.EditTrigger.NoEditTriggers
        )
        self.table.setAlternatingRowColors(True)
        self.table.setWordWrap(False)
        self.table.verticalHeader().setVisible(False)
        self.table.verticalHeader().setDefaultSectionSize(36)
        self.table.horizontalHeader().setMinimumHeight(42)
        self.table.horizontalHeader().setSectionResizeMode(
            QHeaderView.ResizeMode.Stretch
        )
        self.table.horizontalHeader().setSectionResizeMode(
            0, QHeaderView.ResizeMode.Fixed
        )
        self.table.horizontalHeader().setSectionResizeMode(
            9, QHeaderView.ResizeMode.ResizeToContents
        )
        self.table.setColumnWidth(0, 48)
        self.table.setHorizontalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAsNeeded
        )
        self.table.setVerticalScrollBarPolicy(
            Qt.ScrollBarPolicy.ScrollBarAsNeeded
        )
        self.table.setSizePolicy(
            QSizePolicy.Policy.Expanding,
            QSizePolicy.Policy.Expanding if not compact else QSizePolicy.Policy.Fixed,
        )
        if compact:
            self.table.setFixedHeight(220)
            group_layout.setContentsMargins(48, 0, 16, 0)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addLayout(group_layout)
        layout.addWidget(self.table)

    def set_requests(self, requests: list[dict]) -> None:
        self.table.setRowCount(len(requests))
        for row_index, request in enumerate(requests):
            values = [
                request["id"], request["desired_rooms"],
                request["desired_area"], request["desired_floor"],
                request["desired_district"], request["offered_rooms"],
                request["offered_area"], request["offered_floor"],
                request["offered_district"], request["created_at"],
            ]
            for column_index, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
                self.table.setItem(row_index, column_index, item)
