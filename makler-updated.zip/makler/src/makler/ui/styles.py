MAIN_STYLE = """
* { font-family: "SF Pro Display", "Segoe UI", Arial, sans-serif; font-size: 14px; }
QMainWindow, QWidget#requestPage { background: #f7f9fc; color: #111827; }
QScrollArea, QScrollArea QWidget { background: #f7f9fc; border: none; }
#sidebar { background: #eaf4ff; border-right: 1px solid #d5e4f5; }
#sidebarItem { background: transparent; border: none; border-radius: 9px; text-align: left; }
#sidebarItem:hover { background: #e0efff; }
#sidebarItem:checked { background: #d5eaff; }
#sidebarIcon { color: #08639e; font-size: 38px; }
#sidebarIconAdd { background: #078fe5; color: white; border-radius: 9px; font-size: 38px; }
#sidebarTitle { color: #10345d; font-size: 18px; font-weight: 700; }
#sidebarDescription { color: #5d789c; font-size: 14px; }
#pageHeadingIcon, #registryIcon { color: #2586d5; font-size: 36px; }
#pageTitle { color: #101828; font-size: 30px; font-weight: 800; }
#pageDescription { color: #66809f; font-size: 16px; }
#requestCard, #settingsCard, #searchResult { background: white; border: 1px solid #c4d2e3; border-radius: 10px; }
#requestCardHeader { background: #eef2f8; border-bottom: 1px solid #d5deea; }
#requestCardTitle { color: #15213b; font-size: 21px; font-weight: 700; }
#closeButton { background: transparent; border: none; color: #17233d; font-size: 29px; }
#closeButton:hover { color: #2788dc; }
#apartmentForm { background: white; border: 1px solid #c9d8ea; border-radius: 7px; font-weight: 700; padding-top: 8px; }
#apartmentForm[accent="blue"] { border-color: #bdd6f5; }
#apartmentForm[accent="green"] { border-color: #b9ddc7; }
#apartmentForm[accent="blue"]::title { color: #075aa6; }
#apartmentForm[accent="green"]::title { color: #075a32; }
QSpinBox, QDoubleSpinBox, QComboBox { min-height: 34px; background: #f8fafc; border: 1px solid #c4cedb; border-radius: 5px; padding: 0 8px; color: #111827; font-size: 15px; }
QSpinBox:focus, QDoubleSpinBox:focus, QComboBox:focus { border: 1px solid #348bd3; }
QPushButton#findButton { background: #078fe5; color: white; border: none; border-radius: 7px; padding: 0 20px; font-size: 15px; font-weight: 700; }
QPushButton#findButton:hover { background: #087dca; }
QPushButton#cancelButton { background: white; color: #172033; border: 1px solid #aeb9c8; border-radius: 7px; padding: 0 18px; }
QPushButton#cancelButton:hover { background: #f2f5f9; }
#matchResult { background: #f1fbf5; border: 1px solid #a9dabb; border-radius: 9px; }
#matchCheck { background: #168b45; color: white; border-radius: 22px; font-size: 28px; font-weight: 700; }
#matchResultTitle { color: #05662f; font-size: 19px; font-weight: 800; }
#matchResultDescription, #matchDetail { color: #173f2b; font-size: 14px; }
#matchDetails { background: rgba(255,255,255,0.65); border: 1px solid #acd9bc; border-radius: 5px; }
#sectionTitle { color: #111827; font-size: 24px; font-weight: 800; }
#desiredTableHeader { background: #dceaff; color: #0755a5; font-size: 15px; font-weight: 700; padding: 8px; border: 1px solid #c4d9f2; }
#offeredTableHeader { background: #e0f2e5; color: #075a32; font-size: 15px; font-weight: 700; padding: 8px; border: 1px solid #c3dfcb; }
#registryTable { background: white; alternate-background-color: #f7f9fc; border: 1px solid #ccd6e2; gridline-color: #d9e0e8; selection-background-color: #dcecff; selection-color: #111827; }
#registryTable QHeaderView::section { background: #f1f3f7; color: #111827; border: 1px solid #d7dee7; padding: 8px 4px; font-weight: 600; }
#registryTable QTableCornerButton::section { background: #f1f3f7; border: 1px solid #d7dee7; }
#searchResult { background: #f1f7ff; border-color: #b8d4f2; padding: 8px; }
#settingsCard { padding: 8px; }
"""
