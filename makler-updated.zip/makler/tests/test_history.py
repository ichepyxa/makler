from pathlib import Path

from makler.database import Database
from makler.database.models import ExchangeModel
from makler.database.repositories import HistoryRepository, RequestRepository
from makler.domain import Apartment, ExchangeRequest
from makler.services.request_service import RequestService


def make_request(desired_rooms, desired_area, desired_floor, offered_rooms, offered_area, offered_floor):
    return ExchangeRequest(
        desired=Apartment(desired_rooms, desired_area, desired_floor, "Центральный"),
        offered=Apartment(offered_rooms, offered_area, offered_floor, "Советский"),
    )


def test_history_keeps_both_request_snapshots_after_exchange(tmp_path: Path) -> None:
    database = Database(tmp_path / "history.sqlite3")
    database.create_tables()
    first = make_request(2, 52, 3, 3, 65, 5)
    second = make_request(3, 70, 5, 2, 50, 3)

    with database.session() as session:
        RequestRepository(session).add(first)
        session.commit()

    with database.session() as session:
        result = RequestService(session).add_request(second)
        assert result.exchange is not None

    with database.session() as session:
        assert RequestRepository(session).get_all() == []
        history = HistoryRepository(session).get_all()
        assert len(history) == 1
        assert len(history[0].snapshots) == 2
        assert history[0].snapshots[0].request_side == 1
        assert history[0].snapshots[1].request_side == 2
