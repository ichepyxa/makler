from sqlalchemy.exc import SQLAlchemyError
from PySide6.QtWidgets import (
    QHBoxLayout, QMainWindow, QMessageBox, QStackedWidget, QWidget,
)

from makler.database.database import Database
from makler.database.repositories import (
    HistoryRepository, RequestRepository,
)
from makler.domain import Apartment, ExchangeRequest
from makler.services.request_service import RequestService
from makler.ui.history_page import HistoryPage
from makler.ui.registry_page import RegistryPage
from makler.ui.request_page import RequestPage
from makler.ui.search_page import SearchPage
from makler.ui.settings_page import SettingsPage
from makler.ui.widgets.sidebar import Sidebar


class MainWindow(QMainWindow):
    def __init__(self, database: Database) -> None:
        super().__init__()
        self.database = database
        self.setWindowTitle("Маклер — учет заявок на обмен квартир")
        self.resize(1500, 950)
        self.setMinimumSize(1050, 680)

        self.sidebar = Sidebar()
        self.pages = QStackedWidget()
        self.request_page = RequestPage()
        self.search_page = SearchPage()
        self.registry_page = RegistryPage()
        self.history_page = HistoryPage()
        self.settings_page = SettingsPage(database.database_path)

        for page in (
            self.request_page,
            self.search_page,
            self.registry_page,
            self.history_page,
            self.settings_page,
        ):
            self.pages.addWidget(page)

        self.sidebar.page_changed.connect(self._on_page_changed)
        self.sidebar.exit_requested.connect(self.close)
        self.request_page.request_submitted.connect(self._handle_request)
        self.search_page.search_requested.connect(self._handle_search)

        central = QWidget()
        layout = QHBoxLayout(central)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        layout.addWidget(self.sidebar)
        layout.addWidget(self.pages, 1)
        self.setCentralWidget(central)
        self._refresh_registry()

    def _make_request(self, data: dict) -> ExchangeRequest:
        return ExchangeRequest(
            desired=Apartment(**data["desired"]),
            offered=Apartment(**data["offered"]),
        )

    def _handle_request(self, data: dict) -> None:
        try:
            request = self._make_request(data)
            with self.database.session() as session:
                result = RequestService(session).add_request(request)
            self._refresh_registry()
            if result.exchange is not None and result.matched_request is not None:
                self.request_page.show_match_result(
                    result.matched_request_id or 0,
                    self._format_apartment(result.matched_request.desired),
                    self._format_apartment(result.matched_request.offered),
                )
            else:
                self.request_page.show_no_match_result()
        except (SQLAlchemyError, ValueError, TypeError) as error:
            QMessageBox.critical(self, "Ошибка", f"Не удалось обработать заявку: {error}")

    def _handle_search(self, data: dict) -> None:
        try:
            request = self._make_request(data)
            with self.database.session() as session:
                match = RequestService(session).find_match(request)
            if match is None:
                self.search_page.show_no_match()
            else:
                self.search_page.show_match(
                    match.id,
                    self._format_apartment(match.request.desired),
                    self._format_apartment(match.request.offered),
                )
        except (SQLAlchemyError, ValueError, TypeError) as error:
            QMessageBox.critical(self, "Ошибка поиска", str(error))

    def _refresh_registry(self) -> None:
        with self.database.session() as session:
            items = RequestRepository(session).get_all_with_ids()
        rows = [self._request_to_row(item) for item in items]
        self.request_page.set_requests(rows)
        self.registry_page.table.set_requests(rows)

    def _refresh_history(self) -> None:
        with self.database.session() as session:
            records = HistoryRepository(session).get_all()
        self.history_page.set_history(records)

    def _on_page_changed(self, index: int) -> None:
        self.pages.setCurrentIndex(index)
        if index == 2:
            self._refresh_registry()
        elif index == 3:
            self._refresh_history()

    @staticmethod
    def _format_apartment(apartment: Apartment) -> str:
        area = f"{apartment.area:.1f}".replace(".", ",")
        return (
            f"{apartment.rooms} комн., {area} м², "
            f"{apartment.floor} этаж, {apartment.district} район"
        )

    @staticmethod
    def _request_to_row(item) -> dict:
        request = item.request
        return {
            "id": item.id,
            "desired_rooms": request.desired.rooms,
            "desired_area": f"{request.desired.area:.1f}".replace(".", ","),
            "desired_floor": request.desired.floor,
            "desired_district": request.desired.district,
            "offered_rooms": request.offered.rooms,
            "offered_area": f"{request.offered.area:.1f}".replace(".", ","),
            "offered_floor": request.offered.floor,
            "offered_district": request.offered.district,
            "created_at": item.created_at.strftime("%d.%m.%Y"),
        }
