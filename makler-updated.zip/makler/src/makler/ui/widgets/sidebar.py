from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QPushButton, QSizePolicy, QVBoxLayout,
)


class SidebarItem(QPushButton):
    def __init__(self, symbol: str, title: str, description: str, is_add: bool = False, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("sidebarItem")
        self.setCheckable(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumHeight(82)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)

        icon = QLabel(symbol)
        icon.setObjectName("sidebarIconAdd" if is_add else "sidebarIcon")
        icon.setFixedSize(56, 56)
        icon.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title_label = QLabel(title)
        title_label.setObjectName("sidebarTitle")
        description_label = QLabel(description)
        description_label.setObjectName("sidebarDescription")
        description_label.setWordWrap(True)
        for widget in (icon, title_label, description_label):
            widget.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents)

        text_layout = QVBoxLayout()
        text_layout.setContentsMargins(0, 0, 0, 0)
        text_layout.setSpacing(3)
        text_layout.addWidget(title_label)
        text_layout.addWidget(description_label)
        button_layout = QHBoxLayout(self)
        button_layout.setContentsMargins(12, 9, 10, 9)
        button_layout.setSpacing(12)
        button_layout.addWidget(icon)
        button_layout.addLayout(text_layout, 1)


class Sidebar(QFrame):
    page_changed = Signal(int)
    exit_requested = Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("sidebar")
        self.setFixedWidth(310)
        entries = [
            ("＋", "Ввести заявку", "Добавление новой заявки на обмен квартир"),
            ("⌕", "Поиск варианта", "Поиск подходящего варианта обмена"),
            ("▤", "Картотека", "Просмотр всех активных заявок"),
            ("◷", "История обменов", "Завершённые обмены"),
            ("⚙", "Настройки", "Параметры программы"),
        ]
        self.items = [
            SidebarItem(symbol, title, description, is_add=index == 0)
            for index, (symbol, title, description) in enumerate(entries)
        ]
        layout = QVBoxLayout(self)
        layout.setContentsMargins(12, 20, 12, 16)
        layout.setSpacing(8)
        for index, item in enumerate(self.items):
            item.clicked.connect(lambda checked=False, page=index: self._select(page))
            layout.addWidget(item)
        layout.addStretch(1)
        self.exit_item = SidebarItem("⇥", "Выход", "Завершение работы")
        self.exit_item.clicked.connect(self.exit_requested)
        layout.addWidget(self.exit_item)
        self._select(0)

    def _select(self, index: int) -> None:
        for item_index, item in enumerate(self.items):
            item.setChecked(item_index == index)
        self.page_changed.emit(index)
