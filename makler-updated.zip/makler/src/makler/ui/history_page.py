from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QAbstractItemView, QHeaderView, QLabel, QTableWidget,
    QTableWidgetItem, QVBoxLayout, QWidget,
)


class HistoryPage(QWidget):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 26, 30, 30)
        layout.setSpacing(14)

        title = QLabel("История обменов")
        title.setObjectName("pageTitle")
        description = QLabel(
            "Завершённые обмены. Данные сохранены отдельно от активных заявок."
        )
        description.setObjectName("pageDescription")
        layout.addWidget(title)
        layout.addWidget(description)

        self.table = QTableWidget(0, 5)
        self.table.setObjectName("registryTable")
        self.table.setHorizontalHeaderLabels([
            "№ обмена", "Дата", "Участник", "Требуемая квартира", "Имеющаяся квартира",
        ])
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setAlternatingRowColors(True)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setMinimumHeight(42)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        layout.addWidget(self.table, 1)

    @staticmethod
    def _apartment(rooms: int, area: float, floor: int, district: str) -> str:
        return (
            f"{rooms} комн. · {area:.1f} м² · {floor} этаж · {district}"
        ).replace(".", ",", 1)

    def set_history(self, records: list) -> None:
        rows = []
        for record in records:
            for snapshot in record.snapshots:
                rows.append((
                    record.exchange_id,
                    record.created_at.strftime("%d.%m.%Y %H:%M"),
                    f"Заявка {snapshot.request_side}",
                    self._apartment(
                        snapshot.desired_rooms, snapshot.desired_area,
                        snapshot.desired_floor, snapshot.desired_district,
                    ),
                    self._apartment(
                        snapshot.offered_rooms, snapshot.offered_area,
                        snapshot.offered_floor, snapshot.offered_district,
                    ),
                ))
        self.table.setRowCount(len(rows))
        for row_index, values in enumerate(rows):
            self.table.setRowHeight(row_index, 44)
            for column_index, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setTextAlignment(
                    Qt.AlignmentFlag.AlignVCenter | Qt.AlignmentFlag.AlignLeft
                    if column_index >= 3 else Qt.AlignmentFlag.AlignCenter
                )
                self.table.setItem(row_index, column_index, item)
