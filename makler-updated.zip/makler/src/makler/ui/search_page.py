from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QFrame, QHBoxLayout, QLabel, QPushButton, QVBoxLayout, QWidget,
)

from makler.ui.request_page import DISTRICTS
from makler.ui.widgets.apartment_form import ApartmentForm


class SearchPage(QWidget):
    search_requested = Signal(dict)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._build()

    def _build(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 26, 30, 30)
        layout.setSpacing(16)

        title = QLabel("Поиск варианта")
        title.setObjectName("pageTitle")
        description = QLabel(
            "Проверьте, есть ли в картотеке заявка для взаимного обмена. "
            "Предварительный поиск не изменяет данные."
        )
        description.setObjectName("pageDescription")
        layout.addWidget(title)
        layout.addWidget(description)

        card = QFrame()
        card.setObjectName("requestCard")
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(16, 18, 16, 16)
        card_layout.setSpacing(16)

        forms = QHBoxLayout()
        forms.setSpacing(16)
        self.desired_form = ApartmentForm(
            "Требуемая (искомая) квартира", "blue", DISTRICTS
        )
        self.offered_form = ApartmentForm(
            "Имеющаяся квартира", "green", DISTRICTS
        )
        forms.addWidget(self.desired_form, 1)
        forms.addWidget(self.offered_form, 1)
        card_layout.addLayout(forms)

        actions = QHBoxLayout()
        actions.addStretch()
        clear_button = QPushButton("Сбросить")
        clear_button.setObjectName("cancelButton")
        clear_button.clicked.connect(self.reset)
        search_button = QPushButton("Найти в картотеке")
        search_button.setObjectName("findButton")
        search_button.setMinimumHeight(44)
        search_button.clicked.connect(self._search)
        actions.addWidget(clear_button)
        actions.addWidget(search_button)
        card_layout.addLayout(actions)
        layout.addWidget(card)

        self.result = QFrame()
        self.result.setObjectName("searchResult")
        result_layout = QVBoxLayout(self.result)
        self.result_title = QLabel("Результат поиска")
        self.result_title.setObjectName("sectionTitle")
        self.result_text = QLabel(
            "Заполните параметры квартир и нажмите «Найти в картотеке»."
        )
        self.result_text.setObjectName("pageDescription")
        self.result_text.setWordWrap(True)
        result_layout.addWidget(self.result_title)
        result_layout.addWidget(self.result_text)
        self.result.hide()
        layout.addWidget(self.result)
        layout.addStretch(1)

    def _search(self) -> None:
        self.result.hide()
        self.search_requested.emit({
            "desired": self.desired_form.get_values(),
            "offered": self.offered_form.get_values(),
        })

    def show_match(self, request_id: int, desired: str, offered: str) -> None:
        self.result_title.setText(f"Найден взаимный вариант — заявка № {request_id}")
        self.result_text.setText(
            f"Требуемая квартира найденной заявки: {desired}\n"
            f"Имеющаяся квартира найденной заявки: {offered}\n\n"
            "Это предварительный результат: заявки остаются в картотеке. "
            "Для завершения обмена внесите заявку через раздел «Ввести заявку»."
        )
        self.result.show()

    def show_no_match(self) -> None:
        self.result_title.setText("Подходящий вариант не найден")
        self.result_text.setText(
            "В активной картотеке нет заявки, которая соответствует "
            "обеим квартирам по количеству комнат, этажу и площади (±10%)."
        )
        self.result.show()

    def reset(self) -> None:
        self.desired_form.reset()
        self.offered_form.reset()
        self.result.hide()
