from PySide6.QtCore import Qt
from PySide6.QtWidgets import QFormLayout, QFrame, QLabel, QVBoxLayout, QWidget


class SettingsPage(QWidget):
    def __init__(self, database_path, parent=None) -> None:
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 26, 30, 30)
        layout.setSpacing(16)

        title = QLabel("Настройки")
        title.setObjectName("pageTitle")
        description = QLabel("Информация о текущей конфигурации приложения.")
        description.setObjectName("pageDescription")
        layout.addWidget(title)
        layout.addWidget(description)

        card = QFrame()
        card.setObjectName("settingsCard")
        form = QFormLayout(card)
        form.setContentsMargins(22, 20, 22, 20)
        form.setVerticalSpacing(16)
        form.addRow("Приложение:", QLabel("Маклер"))
        form.addRow("Версия:", QLabel("0.1.0"))
        form.addRow("Интерфейс:", QLabel("PySide6 / Qt 6"))
        form.addRow("Хранилище:", QLabel("SQLite"))
        path_label = QLabel(str(database_path))
        path_label.setWordWrap(True)
        path_label.setTextInteractionFlags(
            Qt.TextInteractionFlag.TextSelectableByMouse
        )
        form.addRow("Файл базы данных:", path_label)
        layout.addWidget(card)
        layout.addStretch(1)
