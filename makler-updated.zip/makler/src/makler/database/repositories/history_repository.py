from dataclasses import dataclass
from datetime import datetime

from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from makler.database.models import ExchangeModel


@dataclass(frozen=True, slots=True)
class HistorySnapshot:
    request_side: int
    desired_rooms: int
    desired_area: float
    desired_floor: int
    desired_district: str
    offered_rooms: int
    offered_area: float
    offered_floor: int
    offered_district: str


@dataclass(frozen=True, slots=True)
class HistoryRecord:
    exchange_id: int
    created_at: datetime
    snapshots: tuple[HistorySnapshot, ...]


class HistoryRepository:
    def __init__(self, session: Session) -> None:
        self.session = session

    def get_all(self) -> list[HistoryRecord]:
        statement = (
            select(ExchangeModel)
            .options(selectinload(ExchangeModel.snapshots))
            .order_by(ExchangeModel.created_at.desc(), ExchangeModel.id.desc())
        )
        exchanges = self.session.scalars(statement).all()
        return [
            HistoryRecord(
                exchange_id=exchange.id,
                created_at=exchange.created_at,
                snapshots=tuple(
                    HistorySnapshot(
                        request_side=snapshot.request_side,
                        desired_rooms=snapshot.desired_rooms,
                        desired_area=snapshot.desired_area,
                        desired_floor=snapshot.desired_floor,
                        desired_district=snapshot.desired_district,
                        offered_rooms=snapshot.offered_rooms,
                        offered_area=snapshot.offered_area,
                        offered_floor=snapshot.offered_floor,
                        offered_district=snapshot.offered_district,
                    )
                    for snapshot in sorted(
                        exchange.snapshots,
                        key=lambda item: item.request_side,
                    )
                ),
            )
            for exchange in exchanges
        ]
