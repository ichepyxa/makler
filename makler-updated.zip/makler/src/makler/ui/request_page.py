from PySide6.QtCore import Signal
from PySide6.QtWidgets import (
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from makler.ui.widgets.apartment_form import ApartmentForm
from makler.ui.widgets.match_result import MatchResult
from makler.ui.widgets.registry_table import RegistryTable

DISTRICTS = [
    "Центральный", "Московский", "Советский",
    "Первомайский", "Партизанский", "Фрунзенский",
]


class RequestPage(QWidget):
    request_submitted = Signal(dict)

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setObjectName("requestPage")
        self._create_ui()

    def _create_ui(self) -> None:
        layout = QVBoxLayout(self)
        layout.setContentsMargins(26, 20, 26, 22)
        layout.setSpacing(12)

        heading = QHBoxLayout()
        icon = QLabel("▤")
        icon.setObjectName("pageHeadingIcon")
        title = QLabel("Ввод заявки на обмен квартир")
        title.setObjectName("pageTitle")
        heading.addWidget(icon)
        heading.addWidget(title)
        heading.addStretch()
        layout.addLayout(heading)

        description = QLabel(
            "Укажите квартиру, которую необходимо получить, "
            "и квартиру, предлагаемую для обмена."
        )
        description.setObjectName("pageDescription")
        layout.addWidget(description)

        card = QFrame()
        card.setObjectName("requestCard")
        card_layout = QVBoxLayout(card)
        card_layout.setContentsMargins(16, 0, 16, 14)
        card_layout.setSpacing(12)

        header = QFrame()
        header.setObjectName("requestCardHeader")
        header_layout = QHBoxLayout(header)
        header_layout.setContentsMargins(16, 7, 10, 7)
        card_title = QLabel("Новая заявка на обмен")
        card_title.setObjectName("requestCardTitle")
        clear_button = QPushButton("×")
        clear_button.setObjectName("closeButton")
        clear_button.setFixedSize(34, 34)
        clear_button.setToolTip("Очистить форму")
        clear_button.clicked.connect(self._clear_forms)
        header_layout.addWidget(card_title)
        header_layout.addStretch()
        header_layout.addWidget(clear_button)
        card_layout.addWidget(header)

        forms = QHBoxLayout()
        forms.setSpacing(16)
        self.desired_form = ApartmentForm(
            "Требуемая (искомая) квартира", "blue", DISTRICTS
        )
        self.offered_form = ApartmentForm(
            "Имеющаяся квартира", "green", DISTRICTS
        )
        self.offered_form.area_spin.setValue(60.0)
        self.offered_form.district_combo.setCurrentText("Московский")
        forms.addWidget(self.desired_form, 1)
        forms.addWidget(self.offered_form, 1)
        card_layout.addLayout(forms)

        buttons = QHBoxLayout()
        buttons.addStretch()
        submit = QPushButton("Найти подходящий вариант")
        submit.setObjectName("findButton")
        submit.setMinimumSize(280, 44)
        submit.clicked.connect(self._submit_request)
        cancel = QPushButton("Отмена")
        cancel.setObjectName("cancelButton")
        cancel.setMinimumSize(110, 44)
        cancel.clicked.connect(self._clear_forms)
        buttons.addWidget(submit)
        buttons.addWidget(cancel)
        card_layout.addLayout(buttons)
        layout.addWidget(card)

        self.match_result = MatchResult()
        self.match_result.hide()
        layout.addWidget(self.match_result)

        registry_heading = QHBoxLayout()
        registry_icon = QLabel("☷")
        registry_icon.setObjectName("registryIcon")
        registry_title = QLabel("Картотека заявок")
        registry_title.setObjectName("sectionTitle")
        registry_heading.addWidget(registry_icon)
        registry_heading.addWidget(registry_title)
        registry_heading.addStretch()
        layout.addLayout(registry_heading)

        self.registry_table = RegistryTable(compact=True)
        layout.addWidget(self.registry_table, 1)

    def _submit_request(self) -> None:
        self.match_result.hide()
        self.request_submitted.emit({
            "desired": self.desired_form.get_values(),
            "offered": self.offered_form.get_values(),
        })

    def _clear_forms(self) -> None:
        self.desired_form.reset()
        self.offered_form.reset()
        self.offered_form.area_spin.setValue(60.0)
        self.offered_form.district_combo.setCurrentText("Московский")
        self.match_result.hide()

    def show_match_result(self, request_id: int, desired: str, offered: str) -> None:
        self.match_result.set_match(request_id, desired, offered)

    def show_no_match_result(self) -> None:
        self.match_result.set_no_match()

    def set_requests(self, requests: list[dict]) -> None:
        self.registry_table.set_requests(requests)
